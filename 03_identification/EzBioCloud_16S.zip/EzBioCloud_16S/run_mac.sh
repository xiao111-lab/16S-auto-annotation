#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(/usr/bin/dirname "$0")" && pwd)"
ORIGINAL_PYTHON="$(command -v python3 || true)"
export PATH="/usr/bin:/bin:/usr/sbin:/sbin:/opt/homebrew/bin:/usr/local/bin:${PATH:-}"
FASTA="$ROOT/ALL_101.fasta"
if [[ $# -gt 0 && "$1" != --* ]]; then
  FASTA="$1"
  shift
fi
for PY in \
  "${EZBIO_PYTHON:-/not_found}" \
  "$ROOT/.venv/bin/python" \
  "$HOME/Downloads/EzBioCloud_101_Clean/.venv/bin/python" \
  "$HOME/Downloads/EzBioCloud_Mac_Simple_v0.6/.venv/bin/python" \
  "$HOME/Downloads/EzBioCloud_Mac_Live_v0.7/.venv/bin/python" \
  "${CONDA_PREFIX:-/not_found}/bin/python" \
  "$HOME/miniforge3/bin/python3" "$HOME/miniconda3/bin/python3" \
  "$HOME/anaconda3/bin/python3" \
  /opt/homebrew/bin/python3 /usr/local/bin/python3 "$ORIGINAL_PYTHON"; do
  if [[ -x "$PY" ]] && "$PY" -c 'import sys; from playwright.sync_api import sync_playwright; assert sys.version_info >= (3,10)' >/dev/null 2>&1; then
    exec "$PY" "$ROOT/ezbio_101.py" "$FASTA" "$@"
  fi
done
printf '%s\n' '没有找到同时具备 Python 3.10+ 和 Playwright 的环境。' \
 '请激活你以前成功运行过 v0.6 的 Conda 环境，然后重新启动；或在独立环境安装 playwright。' >&2
exit 1
