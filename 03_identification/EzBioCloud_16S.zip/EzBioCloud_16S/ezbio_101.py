#!/usr/bin/env python3
"""EzBioCloud 16S 101-sample clean run: submit and immediately write real top hits.

Uses visible browser UI only. No private endpoints, remote deletion, screenshots,
password storage in code, or fabricated taxonomy. Log ambiguous submissions for later checking; never automatically submit one twice.
"""
from __future__ import annotations
import argparse
import csv
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re
import sys
import time

URL = 'https://www.ezbiocloud.net/identify'
VALID = set('ACGTRYSWKMBDHVN')
ACTIVE = {'PENDING', 'NOT_SUBMITTED', 'ERROR_BEFORE_SUBMIT'}
RANKS = ('domain', 'phylum', 'class', 'order', 'family', 'genus')
CSV_COLUMNS = ('菌株编号', '域(Domain)', '门(Phylum)', '纲(Class)',
               '目(Order)', '科(Family)', '属(Genus)', '种(Species)', '相似度(%)')
CONFIRM = re.compile(r'^(?:Submit|Confirm|Start Analysis|Start Identification|Run Analysis|Identify Sequence|Finish|Proceed|Done)$', re.I)
PAYMENT = re.compile(r'(?i)(?:pay now|make payment|payment required|purchase credits?|checkout|billing details|payment method|enter card|buy credits?|付款|支付|购买积分)')
CAPTCHA = re.compile(r'(?i)(?:captcha|recaptcha|hcaptcha|verify you are human|human verification|机器人验证|验证码)')
ERROR = re.compile(r'(?i)(?:invalid sequence|sequence is invalid|too many requests|quota exceeded|authentication failed|submit failed|try again later|上传失败|序列无效|配额不足)')


def fasta_records(path):
    if not path.is_file(): raise ValueError(f'找不到 FASTA: {path}')
    out, name, lines, seen = [], None, [], set()
    def add():
        if name is None: return
        dna = ''.join(lines).replace(' ', '').upper()
        if not dna or set(dna) - VALID: raise ValueError(f'{name}: 序列为空或包含非法碱基')
        out.append({'id': name, 'seq': dna, 'sha256': hashlib.sha256(dna.encode()).hexdigest()})
    for raw in path.read_text(encoding='utf-8-sig').splitlines():
        line = raw.strip()
        if not line or line.startswith(';'): continue
        if line.startswith('>'):
            add()
            name = line[1:].strip().split(maxsplit=1)[0] if line[1:].strip() else ''
            if not name or name in seen: raise ValueError('FASTA 中存在空白或重复菌株编号: '+name)
            if not re.fullmatch(r'[\w.-]{1,100}', name, flags=re.UNICODE):
                raise ValueError('菌株编号含特殊符号: '+name)
            seen.add(name); lines = []
        else:
            if name is None: raise ValueError('FASTA 格式错误：缺少 > 菌株编号')
            lines.append(line)
    add()
    if not out: raise ValueError('FASTA 中没有序列')
    return out


def natural_id_key(label):
    return [int(part) if part.isdigit() else part.casefold()
            for part in re.split(r'(\d+)', label)]


def load_state(path, records):
    if path.is_file():
        state = json.loads(path.read_text(encoding='utf-8'))
    else:
        state = {'version': 8, 'samples': {}}
    state['version'] = 8
    for record in records:
        sid = record['id']
        old = state['samples'].get(sid)
        if old and old['sha256'] != record['sha256']:
            raise ValueError(f'{sid}: FASTA 与已有记录不同；请先人工核对或指定一个新的 --output 目录')
        state['samples'].setdefault(sid, {
            'sha256': record['sha256'], 'job_name': sid, 'status': 'PENDING',
            'species': '', 'similarity': '',
            'lineage': {k: '' for k in RANKS}
        })
    return state


def save_state(state, folder):
    folder.mkdir(parents=True, exist_ok=True)
    dst = folder/'.ezbio_state.json'
    temp = folder/'.ezbio_state.json.tmp'
    temp.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding='utf-8')
    temp.replace(dst)
    # Atomic CSV update: every new hit is visible immediately; no duplicate rows.
    # This is deliberately a complete rewrite of at most 101 short rows,
    # which avoids partial/corrupt files when the user interrupts with Ctrl+C.
    csv_dst = folder/'EzBioCloud_16S_top_hits.csv'
    tmp_csv = folder/'EzBioCloud_16S_top_hits.csv.tmp'
    with tmp_csv.open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.writer(f)
        w.writerow(CSV_COLUMNS)
        for sid, rec in state['samples'].items():
            if rec.get('species') and rec.get('similarity'):
                taxonomy = rec.get('lineage') or {}
                w.writerow([sid, *(taxonomy.get(k, '') for k in RANKS),
                            rec['species'], rec['similarity']])
    tmp_csv.replace(csv_dst)


def visible(*locators):
    for loc in locators:
        try:
            for i in range(min(loc.count(), 8)):
                el = loc.nth(i)
                if el.is_visible(): return el
        except Exception: pass
    return None


def logged_in(page):
    return visible(page.get_by_role('button', name=re.compile('^Identify new sequence$', re.I)),
                   page.get_by_role('link', name=re.compile('^Identify new sequence$', re.I)),
                   page.locator('#tab_idSingleSequence')) is not None


def open_form(page):
    field = page.get_by_placeholder(re.compile('^Sequence name$', re.I))
    if visible(field) and visible(page.locator('textarea:visible')): return
    btn = visible(page.get_by_role('button', name=re.compile('^Identify new sequence$', re.I)),
                  page.get_by_role('link', name=re.compile('^Identify new sequence$', re.I)),
                  page.locator('#tab_idSingleSequence'),
                  page.get_by_text(re.compile('^Identify new sequence$', re.I)))
    if btn is None: raise RuntimeError('网页找不到 Identify new sequence')
    btn.click(timeout=12000)
    field.wait_for(state='visible', timeout=12000)


def fill_form(page, name, seq):
    name_el = visible(page.get_by_placeholder(re.compile('^Sequence name$', re.I)),
                      page.locator('input[placeholder*="sequence name" i]'))
    seq_el = visible(page.get_by_role('textbox', name=re.compile('^16S rRNA Sequence$', re.I)),
                     page.locator('textarea[placeholder*="GTA" i]'),
                     page.locator('.modal:visible textarea'), page.locator('textarea:visible'))
    if name_el is None or seq_el is None: raise RuntimeError('找不到菌株编号或序列输入框')
    name_el.fill(name); seq_el.fill(seq)
    if name_el.input_value().strip() != name or re.sub(r'\s+', '', seq_el.input_value()).upper() != seq:
        raise RuntimeError('网站填入的菌株编号或序列与 FASTA 不一致')
    next_el = visible(page.get_by_role('button', name=re.compile('^Next$', re.I)),
                      page.locator('button:visible').filter(has_text=re.compile('^Next$', re.I)))
    if next_el is None: raise RuntimeError('网页找不到 Next')
    return next_el


def page_body(page):
    try: return page.locator('body').inner_text(timeout=4000)[:16000]
    except Exception: return ''


def identification_count(page):
    """Advisory only: total visible website jobs, NOT an identity check."""
    m = re.search(r'My\s+Identifications\s*:\s*(\d+)', page_body(page), re.I)
    return int(m.group(1)) if m else None


def current_dialog(page):
    return visible(page.get_by_role('dialog'), page.locator('.modal:visible'),
                   page.get_by_role('alertdialog'))


def ensure_no_blocker(page):
    modal = current_dialog(page)
    try: text = modal.inner_text(timeout=3000) if modal is not None else page_body(page)
    except Exception: text = page_body(page)
    if PAYMENT.search(text): raise RuntimeError('网站显示付费提示，已停止')
    if CAPTCHA.search(text): raise RuntimeError('网站出现验证码，已停止')
    if ERROR.search(text): raise RuntimeError('网站出现错误/额度限制，已停止: '+text[-180:])


def click_confirmations(page):
    seen = set()
    clicked_count = 0
    for _ in range(3):
        page.wait_for_timeout(1200)
        ensure_no_blocker(page)
        modal = current_dialog(page)
        btn = visible(modal.get_by_role('button', name=CONFIRM)) if modal is not None else None
        if btn is None: btn = visible(page.get_by_role('button', name=CONFIRM))
        if btn is None: return clicked_count
        label = btn.inner_text(timeout=2500).strip()
        scope = modal.inner_text(timeout=2500) if modal is not None else page_body(page)
        fingerprint = label.lower()+'|'+hashlib.sha256(scope.encode()).hexdigest()[:16]
        if fingerprint in seen: raise RuntimeError('提交按钮仍存在，停止以免重复点击')
        seen.add(fingerprint)
        btn.click(timeout=15000)
        clicked_count += 1
    raise RuntimeError('超过三次确认，页面状态不明确')


def norm(s): return re.sub(r'[^a-z0-9]+', '', s.casefold())


def get_row_fields(row):
    cells = row.locator('td')
    values = [re.sub(r'\s+', ' ', cells.nth(i).inner_text(timeout=2500)).strip() for i in range(min(cells.count(), 25))]
    if not values: return {}
    headers = []
    try:
        tab = row.locator('xpath=ancestor::table[1]')
        els = tab.locator('thead th')
        if not els.count(): els = tab.locator('tr').first.locator('th')
        headers = [norm(els.nth(i).inner_text(timeout=2500)) for i in range(min(els.count(),25))]
    except Exception: pass
    if headers and len(headers) == len(values): return dict(zip(headers, values))
    if len(values)>=7:
        return dict(zip(['select', 'tasks', 'name', 'tophittaxon', 'tophitstrain',
                         'similarity', 'tophittaxonomy'], values))
    return {}


def matching_jobs(page, job_name):
    matches=[]
    rows=page.get_by_role('row')
    for i in range(min(rows.count(), 500)):
        try:
            row=rows.nth(i)
            if not row.is_visible(): continue
            fields=get_row_fields(row)
            if fields.get('name', '').strip() == job_name: matches.append(fields)
        except Exception: pass
    return matches


def search_job(page, job_name, *, reload_page=True):
    """Find an exact Name match in the existing task table.

    During collection, reuse the SAME task-list page for all strains. Reload
    the site only once at the beginning of each polling round. The old code
    reloaded it once per sample, making 66 strains look like an endless loop.
    """
    if reload_page:
        page.goto(URL, wait_until='domcontentloaded', timeout=45000)
        page.wait_for_timeout(1100)
    if not logged_in(page): raise RuntimeError('浏览器登录状态失效')
    search = visible(page.get_by_placeholder(re.compile('^Search', re.I)),
                     page.locator('input[type="search"]:visible'))
    if search is not None:
        search.fill(job_name)
        # Keep sufficient debounce time for the website's dynamic table.
        page.wait_for_timeout(950 if not reload_page else 1400)
    found = matching_jobs(page, job_name)
    if not found and search is not None:
        page.wait_for_timeout(650)
        found = matching_jobs(page, job_name)
    if len(found) > 1: raise RuntimeError(f'网站上有多个名为 {job_name} 的任务，停止防止误配')
    return found[0] if len(found)==1 else None


def parse_lineage(raw, species=''):
    """Read the website's Top-hit taxonomy; leave absent/ambiguous ranks blank.

    Normal EzBioCloud lineage:
       Bacteria;Actinomycetota;Actinomycetia;Mycobacteriales;Dietziaceae;Dietzia
    Also supports explicit prefixes d__, p__, c__, o__, f__, g__ or rank=Name.
    The separate Top-hit taxon is the sole source for the species column.
    """
    ranks = {key: '' for key in RANKS}
    raw = (raw or '').strip()
    if not raw or raw.casefold() in {'-', 'none', 'null', 'n/a', 'pending', 'processing'}:
        return ranks
    tokens = [x.strip() for x in re.split(r'[;|]', raw) if x.strip()]
    if not tokens:
        return ranks
    abbreviations = {'d':'domain','k':'domain','p':'phylum','c':'class',
                     'o':'order','f':'family','g':'genus','s':'species'}
    aliases = {'kingdom':'domain', 'superkingdom':'domain'}
    explicit = False
    for token in tokens:
        m = re.match(r'^([dkpcofgs])__(.*)$', token, re.I)
        if m:
            explicit = True
            rank = abbreviations[m.group(1).lower()]
            value = m.group(2).strip()
        else:
            m = re.match(r'^(domain|kingdom|superkingdom|phylum|class|order|family|genus|species)\s*[:=]\s*(.+)$', token, re.I)
            if not m:
                continue
            explicit = True
            rank = aliases.get(m.group(1).lower(), m.group(1).lower())
            value = m.group(2).strip()
        if rank in ranks and value and value not in {'-', '_'}:
            ranks[rank] = value
    if explicit:
        return ranks
    # Strict positional interpretation ONLY for the complete standard hierarchy.
    # Some EzBioCloud versions append a seventh (species) component.
    if len(tokens) in (6, 7) and tokens[0].casefold() in {'bacteria', 'archaea'}:
        for rank, token in zip(RANKS, tokens[:6]):
            ranks[rank] = '' if token in {'-', '_', 'NA', 'N/A'} else token
        return ranks
    # When a partial lineage is displayed, don't shift names into wrong ranks.
    if tokens[0].casefold() in {'bacteria', 'archaea'}:
        ranks['domain'] = tokens[0]
    # Genus-only taxonomy can be confirmed from the web top-hit name.
    first = (species or '').strip().split(' ', 1)[0]
    if first and tokens[-1].casefold() == first.casefold():
        ranks['genus'] = tokens[-1]
    return ranks


def hit_of(row):
    species = (row.get('tophittaxon') or row.get('closestmatch') or row.get('closestspecies') or '').strip()
    similarity = (row.get('similarity') or row.get('similaritypercent') or '').strip()
    if not species or species.casefold() in {'-', 'pending', 'processing', 'n/a', 'null', 'none'}:
        return None
    m = re.fullmatch(r'\s*(\d{1,3}(?:\.\d+)?)\s*%?\s*', similarity)
    if not m or not (0 <= float(m.group(1)) <= 100):
        return None
    raw_lineage = (row.get('tophittaxonomy') or row.get('taxonomy') or '').strip()
    return {'species': species,
            'similarity': f'{float(m.group(1)):.2f}',
            'lineage': parse_lineage(raw_lineage, species)}


def apply_hit(item, hit):
    item.update(species=hit['species'], similarity=hit['similarity'],
                lineage=hit['lineage'], status='IDENTIFIED')


def check_job(page, job_name, max_checks=2):
    """Best-effort immediate lookup; does NOT prove failure if still absent.

    Web jobs can be queued asynchronously and appear in the list later.
    """
    for check in range(max_checks):
        found=search_job(page,job_name)
        if found is not None: return found
        if check+1<max_checks: page.wait_for_timeout(3000)
    return None


def _update_from_row(item, row):
    """Only a matching web-row with a real taxon and similarity is a result."""
    if row is None:
        return False
    hit = hit_of(row)
    if hit is None:
        if item['status'] not in {'IDENTIFIED', 'READ_ONLY_LEGACY'}:
            item['status'] = 'SUBMITTED'
        return False
    apply_hit(item, hit)
    return True


def poll_pending_results(page, state, sample_ids, out, wait_minutes=15.0,
                         interval_seconds=30.0):
    """Read-only collection: one browser page load per round, never re-submit.

    Keeps the existing .ezbio_state.json and results CSV. Search queries on the
    same page are exact-match checked; no species is fabricated for missing hits.
    """
    pending = [sid for sid in sample_ids
               if sid in state['samples']
               and state['samples'][sid]['status'] in
                    {'SUBMITTED', 'PENDING_RESULT', 'READ_ONLY_LEGACY', 'UNCERTAIN', 'MAYBE_SUBMITTED', 'ADOPT_EXISTING'}
               and not (state['samples'][sid].get('species') and
                        state['samples'][sid].get('similarity'))]
    print(f'待收集鉴定结果：{len(pending)} 株；已有完整结果的菌株不会重复查询。', flush=True)
    if not pending:
        return
    end = time.monotonic() + wait_minutes * 60.0
    rounds = 0
    while pending:
        rounds += 1
        print(f'开始第 {rounds} 轮查询：{len(pending)} 株，只打开任务列表一次。', flush=True)
        # One refresh per round suffices to obtain newly finished results.
        page.goto(URL, wait_until='domcontentloaded', timeout=45000)
        page.wait_for_timeout(1500)
        if not logged_in(page):
            print('登录已失效：未提交新任务，保留所有断点。', flush=True)
            return
        next_pending = []
        original_count = len(pending)
        for index, sid in enumerate(pending, 1):
            item = state['samples'][sid]
            try:
                row = search_job(page, item['job_name'], reload_page=False)
            except Exception as e:
                next_pending.extend(pending[index-1:])
                print(f'第 {index} 株查询中断：{str(e)[:160]}；已保存进度，不会重新提交。', flush=True)
                save_state(state, out)
                return
            if _update_from_row(item, row):
                print(f'  ✓ {sid} → {item["species"]} | {item["similarity"]}%（已实时写入 CSV）', flush=True)
            else:
                next_pending.append(sid)
            save_state(state, out)
            if index % 10 == 0 or index == original_count:
                print(f'  已检查 {index}/{original_count} 株；本轮获得 {index - len(next_pending)} 条结果。', flush=True)
        pending = next_pending
        if not pending:
            print('全部待查询样品已取得 Top-hit 和相似度。', flush=True)
            return
        left = max(0.0, end - time.monotonic())
        if left <= 0:
            break
        wait = min(left, interval_seconds)
        print(f'还有 {len(pending)} 株没有获取到 Top-hit；'
              f'{round(left / 60, 1)} 分钟后结束等待，{round(wait)} 秒后再核对。', flush=True)
        page.wait_for_timeout(max(1, int(wait * 1000)))
    print(f'本次查询结束：仍有 {len(pending)} 株尚未得到完整结果。'
          '所有进度已保存，后续继续运行 collect 即可；没有重新提交任务。', flush=True)



def harvest_some(page, state, sample_ids, out, max_count=12):
    """Interleave harvesting with submission, using one task-table page load.

    Rotate through the pending IDs instead of always querying the oldest few.
    Keep previous results after any interruption by atomically saving each hit.
    This function NEVER creates or deletes website tasks.
    """
    pending = [sid for sid in sample_ids
               if sid in state['samples']
               and state['samples'][sid]['status'] in
                    {'SUBMITTED', 'PENDING_RESULT', 'READ_ONLY_LEGACY', 'UNCERTAIN', 'MAYBE_SUBMITTED', 'ADOPT_EXISTING'}
               and not (state['samples'][sid].get('species') and
                        state['samples'][sid].get('similarity'))]
    if not pending or max_count <= 0: return 0
    cursor = int(state.get('sweep_cursor', 0)) % len(pending)
    subset = [pending[(cursor+i) % len(pending)] for i in range(min(max_count, len(pending)))]
    state['sweep_cursor'] = (cursor + len(subset)) % len(pending)
    n = 0
    page.goto(URL, wait_until='domcontentloaded', timeout=45000)
    page.wait_for_timeout(1000)
    if not logged_in(page): raise RuntimeError('登录失效，停止批量操作')
    for sid in subset:
        item = state['samples'][sid]
        row = search_job(page, item['job_name'], reload_page=False)
        if _update_from_row(item, row):
            n += 1
            save_state(state, out)
            print(f'  ✓ {sid} → {item["species"]} | {item["similarity"]}%（已实时写入 CSV）', flush=True)
    save_state(state, out)
    print(f'  穿插收集：检查 {len(subset)} 株，新增结果 {n} 株。', flush=True)
    return n



def submit_and_collect(page, args, state, records, out):
    all_sample_ids = list(state['samples'])
    submitted_this_run = 0
    unverified_streak = 0
    failures = []
    for i, r in enumerate(records, 1):
        sid, seq = r['id'], r['seq']
        item = state['samples'][sid]
        job = item['job_name']
        print(f'[{i}/{len(records)}] 菌株 {sid} → 网站任务 {job}', flush=True)

        # Existing records are queried, never resubmitted.
        if item['status'] in {'SUBMITTED', 'PENDING_RESULT', 'READ_ONLY_LEGACY',
                              'UNCERTAIN', 'MAYBE_SUBMITTED', 'ADOPT_EXISTING'}:
            row = search_job(page, job)
            if row is None:
                print('  已有本地提交记录但网站暂未查到：'+job+'；不会重复提交，转入结束后的补查。', flush=True)
                failures.append(sid)
                save_state(state, out)
                continue
            elif _update_from_row(item, row):
                print(f'  ✓ {sid} → {item["species"]} | {item["similarity"]}%（已实时写入 CSV）', flush=True)
            else:
                print('  已有任务，结果尚未显示，稍后继续收集。', flush=True)
            save_state(state, out)
            continue

        if item['status'] not in ACTIVE:
            print('  状态 '+item['status']+'；不自动重复提交。', flush=True)
            continue
        try:
            existing = search_job(page, job)
        except Exception as e:
            print('  读取任务列表失败，停止：'+str(e)[:200], flush=True)
            return
        if existing is not None:
            if args.existing == 'reuse':
                item['status'] = 'ADOPT_EXISTING'
                if _update_from_row(item, existing):
                    print(f'  ✓ 已读取同名任务 {sid}：{item["species"]} | {item["similarity"]}%（CSV 已更新）', flush=True)
                else:
                    print('  发现同名任务，但尚无物种结果；稍后收集。', flush=True)
                save_state(state, out)
                continue
            print(f'  停止：网站已有名称为 {sid} 的任务。请先核实/清理旧任务；'
                  '或确认序列相同后使用 --existing reuse。', flush=True)
            return

        clicked = False
        count_before = identification_count(page)
        try:
            page.goto(URL, wait_until='domcontentloaded', timeout=45000)
            open_form(page)
            nxt = fill_form(page, job, seq)
            ensure_no_blocker(page)
            # Journal BEFORE clicking Next: if the browser closes at the
            # transition, resume will query this job rather than submit twice.
            item['status'] = 'MAYBE_SUBMITTED'
            item['attempted_at'] = datetime.now().astimezone().isoformat()
            save_state(state, out)
            clicked = True
            nxt.click(timeout=18000)
            confirm_count = click_confirmations(page)
            item['confirmation_clicks'] = confirm_count
            save_state(state, out)
            # A slow index/search result is NOT proof that submission failed.
            row = check_job(page, job)
            if row is None:
                unverified_streak += 1
                print('  已点击 Next/确认，但列表暂未查到任务；已记录为待核实，继续下一株，绝不自动重发。', flush=True)
                failures.append(sid)
                count_after = identification_count(page)
                if count_before is not None and count_after is not None and count_after > count_before:
                    # A rising total is only a hint, not a Name match. Never
                    # treat it as a real identification or as permission to retry.
                    print(f'  网站任务总数 {count_before} → {count_after}；可能已收录，但仍待核实 Name 列。', flush=True)
                    unverified_streak = 0
            elif _update_from_row(item, row):
                unverified_streak = 0
                print(f'  ✓ {sid} → {item["species"]} | {item["similarity"]}%（已实时写入 CSV）', flush=True)
            else:
                unverified_streak = 0
                print('  网站已找到此任务，鉴定结果尚未返回；继续下一株。', flush=True)
            save_state(state, out)
            submitted_this_run += 1
            if unverified_streak >= args.max_unverified_streak:
                print(f'  连续 {unverified_streak} 株在任务列表中无法核实。为避免大量失败提交，暂停新增任务；'
                      '已尝试的菌株会在下一步只读补查，不会重新提交。', flush=True)
                break
            if args.delay > 0:
                page.wait_for_timeout(round(args.delay * 1000))
            if args.collect_every and submitted_this_run % args.collect_every == 0:
                harvest_some(page, state, all_sample_ids, out, args.sweep_size)
        except Exception as e:
            item['status'] = 'MAYBE_SUBMITTED' if clicked else 'ERROR_BEFORE_SUBMIT'
            item['last_error'] = str(e)[:500]
            save_state(state, out)
            if clicked and not any(word in str(e).casefold() for word in
                                   ('验证码', 'captcha', '支付', '付费', 'payment', '购买',
                                    '登录', 'auth', 'quota', 'too many requests',
                                    '重复点击', '超过三次确认')):
                unverified_streak += 1
                failures.append(sid)
                print('  提交后网页状态不明确：'+str(e)[:140]+'；不重发本株，继续后续样品。', flush=True)
                if unverified_streak >= args.max_unverified_streak:
                    print('  达到连续未核实任务的安全阈值，暂停新任务提交，转入结果收集。',flush=True)
                    break
                continue
            print('  遇到明确错误，停止新任务提交：'+str(e)[:240], flush=True)
            break

    # Automatic result collection, including jobs submitted in previous sessions.
    pending_ids = [r['id'] for r in records]
    poll_pending_results(page, state, pending_ids, out,
                         wait_minutes=args.wait_minutes)
    remaining = [sid for sid in pending_ids if state['samples'][sid]['status'] in
                 {'MAYBE_SUBMITTED', 'UNCERTAIN', 'SUBMITTED'}
                 and not state['samples'][sid].get('species')]
    if remaining:
        print(f'有 {len(remaining)} 株尚未取得可靠 Top-hit（可能仍在计算或未查到任务）：'
              ', '.join(remaining), flush=True)
        print('这些样品不会自动重发；请使用 --mode collect 继续查询，或先到网站确认。', flush=True)

def run_browser(args, state, records, out):
    try:
        from playwright.sync_api import sync_playwright
    except ImportError as e:
        raise RuntimeError('缺少 Playwright，请使用 run_mac.sh 启动') from e
    profile = (args.profile or out/'.chrome_profile').expanduser().resolve()
    profile.mkdir(parents=True, exist_ok=True)
    with sync_playwright() as p:
        context = p.chromium.launch_persistent_context(
            user_data_dir=str(profile), channel='chrome', headless=False,
            viewport={'width':1380, 'height':920}, args=['--no-first-run'])
        try:
            page = context.pages[0] if context.pages else context.new_page()
            page.goto(URL, wait_until='domcontentloaded', timeout=45000)
            if not logged_in(page):
                print('请在弹出的 Chrome 登录 EzBioCloud（最多等待 5 分钟）。')
                until = time.monotonic() + 300
                while time.monotonic() < until:
                    page.wait_for_timeout(2000)
                    if logged_in(page): break
                else:
                    raise RuntimeError('未能确认登录，停止')

            if args.mode == 'collect':
                # The previous implementation queried each sample once, THEN
                # started the polling loop, causing 2+ page loads per sample.
                # Collection needs only the single-page-per-round poller.
                poll_pending_results(page, state, [r['id'] for r in records],
                                     out, wait_minutes=args.wait_minutes)
                return

            submit_and_collect(page, args, state, records, out)
        finally:
            context.close()


def main(argv=None):
    ap=argparse.ArgumentParser(description='EzBioCloud 101 重启修正版：原始编号，实时保存域/门/纲/目/科/属/种与相似度')
    ap.add_argument('fasta', type=Path)
    ap.add_argument('--mode', choices=['prepare','run','collect'], default='run')
    ap.add_argument('--ids', default='', help='只处理某些菌株，例如 19,20')
    ap.add_argument('--limit', default='all', help='默认处理全部菌株；也可指定1或其他正整数')
    ap.add_argument('--output', type=Path, default=Path.home()/'Downloads'/'EzBioCloud_101_Restart_Results')
    ap.add_argument('--profile', type=Path, default=None)
    ap.add_argument('--delay', type=float, default=4.0)
    ap.add_argument('--max-unverified-streak', type=int, default=12,
                    help='连续多少株仍未被网站任务列表核实则暂停新增提交，默认12')
    ap.add_argument('--collect-every', type=int, default=5, help='每新提交多少株穿插收集一次结果；默认5')
    ap.add_argument('--sweep-size', type=int, default=15, help='每次穿插检查多少个待完成任务；默认15')
    ap.add_argument('--existing', choices=['stop','reuse'], default='stop', help='遇到网站已有同名任务：默认停止；明确确认同名=同序列时可 reuse')
    ap.add_argument('--reset-missing', default='', help='人工确认网站上没有该菌株任务后，将本地不确定记录恢复待提交，例如 18（仅修改本地）')
    ap.add_argument('--wait-minutes', type=float, default=15.0,
                    help='提交后/collect 时自动轮询分类结果的时间上限，默认 15 分钟')
    ap.add_argument('--yes', action='store_true', help='同意启动本批次，无需再输入 START')
    args=ap.parse_args(argv)
    if args.limit!='all' and (not args.limit.isdigit() or int(args.limit)<1): ap.error('--limit 应为正整数或 all')
    if not 0 <= args.delay <= 600: ap.error('--delay 必须是 0-600 秒')
    if not 1 <= args.max_unverified_streak <= 101: ap.error('--max-unverified-streak 必须在 1-101 之间')
    if args.collect_every < 0 or args.sweep_size < 1 or args.sweep_size > 100: ap.error('--collect-every 与 --sweep-size 参数无效')
    if not 0 <= args.wait_minutes <= 1440: ap.error('--wait-minutes 必须为 0-1440 分钟')
    records=sorted(fasta_records(args.fasta.expanduser()), key=lambda x: natural_id_key(x['id']))
    if args.ids:
        ids={a.strip() for a in args.ids.split(',') if a.strip()}
        unseen=ids-{r['id'] for r in records}
        if unseen: ap.error('FASTA 中找不到编号: '+','.join(sorted(unseen)))
        records=[r for r in records if r['id'] in ids]
    out=args.output.expanduser().resolve()
    state=load_state(out/'.ezbio_state.json',records)
    if args.reset_missing:
        sid=args.reset_missing.strip()
        if sid not in state['samples']: ap.error('--reset-missing 菌株编号不在此次 FASTA 内')
        rec=state['samples'][sid]
        if rec.get('species') and rec.get('similarity'):
            ap.error('此菌株已有鉴定结果；不能直接重置')
        if rec.get('status') not in {'UNCERTAIN','MAYBE_SUBMITTED','SUBMITTED','PENDING_RESULT','ADOPT_EXISTING','READ_ONLY_LEGACY','ERROR_BEFORE_SUBMIT'}:
            ap.error('此菌株状态不需要重置：'+rec.get('status',''))
        if input(f'请确认你已经在 EzBioCloud 网站核实不存在名为 {rec["job_name"]} 的任务；输入 RESET {sid}：').strip() != 'RESET '+sid:
            print('取消重置'); return 0
        rec['status']='PENDING'
        save_state(state,out)
        print('已将 '+sid+' 恢复为本地 PENDING；请再用 --mode run 执行。')
        return 0
    if args.mode == 'run':
        # A submitted, still-pending job must be collected, not re-submitted.
        records=[r for r in records if state['samples'][r['id']]['status'] != 'IDENTIFIED']
    if args.limit!='all': records=records[:int(args.limit)]
    save_state(state,out)
    print(f'读取 FASTA：{len(fasta_records(args.fasta.expanduser()))} 株；本次处理：{len(records)} 株')
    print('实时结果文件：',out/'EzBioCloud_16S_top_hits.csv')
    print(f'查询设置：每提交 {args.collect_every} 株穿插收集，每轮最多核对 {args.sweep_size} 株。', flush=True)
    n_done = sum(bool(x.get('species') and x.get('similarity'))
                 for x in state['samples'].values())
    print(f'已保存真实 Top-hit：{n_done} 株；每出现一株结果会立即更新 CSV。', flush=True)
    if args.mode=='prepare' or not records: return 0
    if args.mode=='run' and not args.yes and any(
            state['samples'][r['id']]['status'] in ACTIVE for r in records):
        if input('确认开始本批自动提交？输入 START：').strip() != 'START':
            print('已取消'); return 0
    run_browser(args,state,records,out)
    save_state(state,out)
    return 0

if __name__=='__main__':
    try: sys.exit(main())
    except (ValueError,RuntimeError,KeyboardInterrupt) as e:
        print('程序停止：'+str(e),file=sys.stderr);sys.exit(1)
