from pathlib import Path
from types import SimpleNamespace
import tempfile, importlib.util, csv
sp=importlib.util.spec_from_file_location('ez',Path(__file__).with_name('ezbio_101.py'))
m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
all_items=m.fasta_records(Path(__file__).with_name('ALL_101.fasta'))
assert len(all_items)==101 and len({i['id'] for i in all_items})==101
items=all_items[:4]
site={}
class Page:
 def goto(self,*a,**k):pass
 def wait_for_timeout(self,*a):pass
class Next:
 def __init__(self,job):self.job=job
 def click(self,**kw):site[self.job]={'name':self.job,'tophittaxon':'Dietzia maris','similarity':'99.93','tophittaxonomy':'Bacteria;Actinomycetota;Actinomycetia;Mycobacteriales;Dietziaceae;Dietzia'}
page=Page()
args=SimpleNamespace(delay=0,collect_every=0,sweep_size=2,existing='stop',max_unverified_streak=12,wait_minutes=0.1)
old={k:getattr(m,k) for k in ['search_job','open_form','fill_form','ensure_no_blocker','click_confirmations','check_job','poll_pending_results']}
try:
 m.search_job=lambda page,job,**kw:site.get(job)
 m.open_form=lambda page:None
 m.fill_form=lambda page,job,seq:Next(job)
 m.ensure_no_blocker=lambda page:None
 m.click_confirmations=lambda page:1
 m.check_job=lambda page,job:None # simulate the EXACT defect: no immediate task confirmation
 def collect(page,state,ids,out,**kw):
  for sid in ids:
   if sid in site:
    m._update_from_row(state['samples'][sid],site[sid]);m.save_state(state,out)
 m.poll_pending_results=collect
 with tempfile.TemporaryDirectory() as td:
  folder=Path(td)
  state=m.load_state(folder/'.ezbio_state.json',items)
  m.submit_and_collect(page,args,state,items,folder)
  rows=list(csv.DictReader((folder/'EzBioCloud_16S_top_hits.csv').open(encoding='utf-8-sig')))
  assert len(rows)==4 and len(site)==4,(len(rows),list(site))
  assert all(x['种(Species)']=='Dietzia maris' for x in rows)
  assert all(x['域(Domain)']=='Bacteria' for x in rows)
  assert all(state['samples'][r['id']]['status']=='IDENTIFIED' for r in items)
  # simulate restart: same sequence never resubmits
  def disallow_fill(*a): raise AssertionError('resubmitted!')
  m.fill_form=disallow_fill
  m.submit_and_collect(page,args,state,items,folder)
  rows2=list(csv.DictReader((folder/'EzBioCloud_16S_top_hits.csv').open(encoding='utf-8-sig')))
  assert len(rows2)==4
 print('PASS: 101 FASTA, no immediate verification on 4 sequential submissions, 4 later fetched, 9-col CSV, no duplicate on restart')
finally:
 for k,v in old.items():setattr(m,k,v)
