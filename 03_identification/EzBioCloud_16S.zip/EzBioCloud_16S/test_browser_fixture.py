"""Offline browser regression: delayed result-list visibility never aborts on 1st sample."""
from pathlib import Path
from types import SimpleNamespace
import tempfile, threading, http.server, importlib.util, csv
from playwright.sync_api import sync_playwright

spec=importlib.util.spec_from_file_location('ezbio101',Path(__file__).with_name('ezbio_101.py'))
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
html = r'''<!DOCTYPE html><meta charset="utf-8"><title>Offline Test EzBioCloud</title>
<button id="tab_idSingleSequence" onclick="document.querySelector('#modal').style.display='block'">Identify new sequence</button>
<h1>My Identifications: <span id="n">0</span></h1>
<input placeholder="Search" id="search" oninput="render()">
<table><thead><tr><th></th><th>Tasks</th><th>Name</th><th>Top-hit taxon</th><th>Top-hit strain</th><th>Similarity (%)</th><th>Top-hit taxonomy</th></tr></thead><tbody id="rows"></tbody></table>
<div class="modal" role="dialog" id="modal" style="display:none"><h2>Identify New Sequence</h2>
<input id="sn" placeholder="Sequence name"><textarea id="sq" placeholder="GTAACAGA..."></textarea>
<button id="next" onclick="this.style.display='none';document.querySelector('#submit').style.display='inline'">Next</button>
<button id="submit" style="display:none" onclick="submitJob()">Submit</button></div>
<script>
let jobs = JSON.parse(localStorage.getItem('jobs')||'[]');
function render(){
 let q=document.querySelector('#search').value;
 document.querySelector('#n').textContent=jobs.length;
 document.querySelector('#rows').innerHTML=jobs.filter(x=>!q||x.name.includes(q)).map(x=>
 `<tr><td><input type='checkbox'></td><td>+</td><td>${x.name}</td><td>${x.species}</td><td>DSM X</td><td>99.93</td><td>Bacteria;Actinomycetota;Actinomycetia;Mycobacteriales;Dietziaceae;Dietzia</td></tr>`).join('');
}
function submitJob(){
 let n=document.querySelector('#sn').value;
 jobs.push({name:n,species:'Dietzia maris'});localStorage.setItem('jobs',JSON.stringify(jobs));
 document.querySelector('#modal').style.display='none';document.querySelector('#next').style.display='inline';document.querySelector('#submit').style.display='none';render();
}
render();
</script>'''
with tempfile.TemporaryDirectory() as td:
 root=Path(td); (root/'index.html').write_text(html)
 class Handler(http.server.SimpleHTTPRequestHandler):
  def __init__(self,*args,**kwargs):super().__init__(*args,directory=str(root),**kwargs)
  def log_message(self,*args):pass
 server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler)
 threading.Thread(target=server.serve_forever,daemon=True).start()
 m.URL=f'http://127.0.0.1:{server.server_port}/index.html'
 items=m.fasta_records(Path(__file__).with_name('ALL_101.fasta'))[:3]
 state=m.load_state(root/'.ezbio_state.json',items)
 args=SimpleNamespace(delay=0,collect_every=1,sweep_size=2,existing='stop',max_unverified_streak=12,wait_minutes=0.1)
 orig=m.check_job
 m.check_job=lambda *a,**kw:None # The real defect: task not yet indexed after submit
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox'])
  page=browser.new_page()
  page.goto(m.URL)
  m.submit_and_collect(page,args,state,items,root)
  browser.close()
 m.check_job=orig
 rows=list(csv.DictReader((root/'EzBioCloud_16S_top_hits.csv').open(encoding='utf-8-sig')))
 assert len(rows)==3,(len(rows),rows)
 assert all(r['种(Species)']=='Dietzia maris' and r['相似度(%)']=='99.93' for r in rows)
 assert all(state['samples'][r['id']]['status']=='IDENTIFIED' for r in items)
 print('PASS browser mock: 3 submit attempts, immediate verification returns None for ALL; no early exit; online task-list collection recovered ALL 3 and updated CSV')
 server.shutdown()
