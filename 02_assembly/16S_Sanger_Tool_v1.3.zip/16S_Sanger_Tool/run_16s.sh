#!/usr/bin/env bash
set -euo pipefail
TOOL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ "$#" -eq 0 ]; then
  printf '请输入包含AB1和SEQ文件的文件夹完整路径: '
  IFS= read -r INPUT_DIR
else
  INPUT_DIR="$1"
  shift
fi
INPUT_DIR="${INPUT_DIR/#\~/$HOME}"
if [ ! -d "$INPUT_DIR" ]; then
  echo "错误：文件夹不存在：$INPUT_DIR" >&2
  exit 1
fi
if ! command -v python3 >/dev/null 2>&1; then
  echo '错误：找不到 python3。请先安装 Python 3.10–3.13。' >&2
  exit 1
fi
python3 - <<'PY'
import sys
if not ((3,10) <= sys.version_info[:2] <= (3,13)):
    raise SystemExit('错误：当前工具支持 Python 3.10–3.13，当前为 '+sys.version.split()[0])
PY
VENV="$TOOL_DIR/.venv"
PYTHON="$VENV/bin/python"
# A previous failed pip install can leave .venv/bin/python in place without Bio.
# Always check actual imports; never equate existence of a venv with successful installation.
if [ ! -x "$PYTHON" ]; then
  echo '正在创建本工具专用 Python 环境（不修改 Conda base 环境）。'
  python3 -m venv "$VENV"
fi
if ! "$PYTHON" -c 'from Bio import SeqIO; from Bio.Align import PairwiseAligner; from Bio.Seq import Seq' >/dev/null 2>&1; then
  echo '正在安装 Biopython 1.85 的预编译包（无需 C 编译器；需要联网）。'
  # Biopython 1.88 lacks a macOS x86_64 wheel for Python 3.10, which causes
  # ARM-only Apple Command Line Tools to fail building from source on Rosetta/Conda.
  # 1.85 provides macOS x86_64 and arm64 wheels for Python 3.10.
  if ! "$PYTHON" -m pip install --only-binary=:all: --retries 5 --timeout 120 'biopython==1.85'; then
    echo '错误：安装 Biopython 失败。请检查网络或 pip 镜像配置；不会继续执行组装。' >&2
    exit 1
  fi
fi
if ! "$PYTHON" -c 'from Bio import SeqIO; from Bio.Align import PairwiseAligner; from Bio.Seq import Seq' >/dev/null 2>&1; then
  echo '错误：Biopython 依赖仍无法导入，请把终端报错发给我排查。' >&2
  exit 1
fi
"$PYTHON" "$TOOL_DIR/assemble_16s.py" --input "$INPUT_DIR" "$@"
