"""Run: python tests.py after installing Biopython."""
import argparse
import random
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from assemble_16s import scan_files
from Bio.Seq import Seq
from assemble_16s import assemble, split_name, trim_quality

class Tests(unittest.TestCase):
    def args(self, **kwargs):
        d=dict(window=40,window_q=25,min_read=150,min_overlap=150,
            min_identity=99.0,max_tail_discard=80,max_mismatches=3,
            min_q_diff=10,confident_q=30,max_draft_indels=10,
            disable_auto_indel=False,auto_indel_max_q=10,
            auto_indel_support_q=35,auto_indel_anchor=20)
        d.update(kwargs)
        return argparse.Namespace(**d)

    @staticmethod
    def reads():
        rng = random.Random(321)
        full = ''.join(rng.choice('ACGT') for _ in range(1350))
        f = full[:940]
        r = str(Seq(full[470:]).reverse_complement())
        return full,f,r

    def test_name_parsing(self):
        a=split_name(Path('6_27F.ab1'))
        b=split_name(Path('6_1492R.ab1'))
        self.assertEqual(a[:2],b[:2]); self.assertEqual(a[1],'6')
        self.assertEqual(a[2],'27F'); self.assertEqual(b[2],'1492R')
        c=split_name(Path('N6_32226093000417_(6)_[27F].ab1'))
        d=split_name(Path('N6_32226093000417_(6)_[1492R].ab1'))
        self.assertEqual(c[:2],d[:2])

    def test_skips_old_result_fasta_when_rescanning(self):
        with TemporaryDirectory() as tmp:
            p = Path(tmp)
            (p/'6_27F.ab1').write_bytes(b'not-real-abi')
            (p/'6_1492R.ab1').write_bytes(b'not-real-abi')
            other=p/'16S_results'/'01_QC'
            other.mkdir(parents=True)
            (other/'6_27F_trimmed.fasta').write_text('>fake\nACGT\n')
            result=scan_files(p,p/'16S_results_v1.2')
            self.assertEqual(len(result),1)

    def test_quality_trim(self):
        seq='A'*15+'ACGT'*200+'T'*20
        q=[5]*15+[40]*800+[5]*20
        a,b,s,_=trim_quality(seq,q,40,25,150)
        self.assertGreater(a,0)
        self.assertLess(b,len(seq))
        self.assertGreaterEqual(len(s),700)

    def test_clean(self):
        full,f,r=self.reads()
        result=assemble(dict(seq=f,q=[52]*len(f),crosscheck='MATCH'),
                        dict(seq=r,q=[51]*len(r),crosscheck='MATCH'),self.args())
        self.assertEqual(result['status'],'PASS')
        self.assertEqual(result['consensus'],full)
        self.assertEqual(result['mismatches'],0)
        self.assertEqual(result['overlap'],470)

    def mutate_in_r(self, r, idx):
        new_base = 'A' if r[idx]!='A' else 'C'
        return r[:idx]+new_base+r[idx+1:]

    def test_one_confident_mismatch_passes(self):
        full,f,r=self.reads()
        idx=600
        r2=self.mutate_in_r(r, idx)
        q=[51]*len(r2); q[idx]=15
        result=assemble(dict(seq=f,q=[52]*len(f),crosscheck='MATCH'),
                        dict(seq=r2,q=q,crosscheck='MATCH'),self.args())
        self.assertEqual(result['status'],'PASS')
        self.assertEqual(result['consensus'],full)
        self.assertEqual(result['mismatches'],1)
        self.assertEqual(result['resolved_mismatches'],1)

    def test_close_quality_mismatch_requires_review(self):
        full,f,r=self.reads()
        r2=self.mutate_in_r(r,600)
        result=assemble(dict(seq=f,q=[52]*len(f),crosscheck='MATCH'),
                        dict(seq=r2,q=[51]*len(r2),crosscheck='MATCH'),self.args())
        self.assertEqual(result['status'],'REVIEW')
        self.assertEqual(result['unresolved_mismatches'],1)
        self.assertIn('N',result['consensus'])

    def test_large_mismatch_count_requires_review(self):
        full,f,r=self.reads()
        q=[45]*len(r)
        for idx in (580,600,620,640,660):
            r=self.mutate_in_r(r,idx)
            q[idx]=15
        result=assemble(dict(seq=f,q=[52]*len(f),crosscheck='MATCH'),
                        dict(seq=r,q=q,crosscheck='MATCH'),self.args())
        self.assertEqual(result['status'],'REVIEW')
        self.assertEqual(result['mismatches'],5)
        self.assertEqual(result['resolved_mismatches'],5)

    def test_internal_indel_draft_not_pass(self):
        full,f,r=self.reads()
        # Deleting one base in an interior overlap of the original raw R read.
        r2=r[:600]+r[601:]
        result=assemble(dict(seq=f,q=[52]*len(f),crosscheck='MATCH'),
                        dict(seq=r2,q=[51]*len(r2),crosscheck='MATCH'),self.args())
        self.assertEqual(result['status'],'REVIEW')
        self.assertGreaterEqual(result['gaps'],1)
        self.assertGreater(len(result['consensus']),1200)
        self.assertTrue(result['indels'])

    def test_single_lowq_homopolymer_indel_suggests_correction(self):
        full,f,r=self.reads()
        pos=501  # TTT repeat in synthetic reverse read; alignment gap may slide.
        self.assertEqual(r[pos],r[pos+1])
        r2=r[:pos]+r[pos]+r[pos:]
        qs=[51]*len(r2);qs[pos]=6
        z=assemble(dict(seq=f,q=[52]*len(f),crosscheck='MATCH'),
                   dict(seq=r2,q=qs,crosscheck='MATCH'),self.args())
        self.assertEqual(z['status'],'AUTO_CORRECTED')
        self.assertEqual(z['consensus'],full)
        self.assertEqual(z['auto_corrected_indels'],1)
        self.assertEqual(z['indels'][0]['evidence']['repeat_run_lowest_Q'],6)

    def test_highq_indel_is_not_auto_corrected(self):
        full,f,r=self.reads()
        pos=501
        r2=r[:pos]+r[pos]+r[pos:]
        z=assemble(dict(seq=f,q=[52]*len(f),crosscheck='MATCH'),
                   dict(seq=r2,q=[51]*len(r2),crosscheck='MATCH'),self.args())
        self.assertEqual(z['status'],'REVIEW')
        self.assertEqual(z['auto_corrected_indels'],0)

    def test_indel_can_be_disabled(self):
        full,f,r=self.reads()
        pos=501
        r2=r[:pos]+r[pos]+r[pos:]
        qs=[51]*len(r2);qs[pos]=6
        z=assemble(dict(seq=f,q=[52]*len(f),crosscheck='MATCH'),
                   dict(seq=r2,q=qs,crosscheck='MATCH'),self.args(disable_auto_indel=True))
        self.assertEqual(z['status'],'REVIEW')
        self.assertEqual(z['auto_corrected_indels'],0)

    def test_missing_strong_flanking_support_indel_review(self):
        full,f,r=self.reads()
        pos=501
        r2=r[:pos]+r[pos]+r[pos:]
        qs=[51]*len(r2);qs[pos]=6
        z=assemble(dict(seq=f,q=[32]*len(f),crosscheck='MATCH'),
                   dict(seq=r2,q=qs,crosscheck='MATCH'),self.args())
        self.assertEqual(z['status'],'REVIEW')
        self.assertEqual(z['auto_corrected_indels'],0)

    def test_zero_mismatch_allowed(self):
        full,f,r=self.reads()
        r2=self.mutate_in_r(r,600)
        q=[51]*len(r2);q[600]=15
        result=assemble(dict(seq=f,q=[52]*len(f),crosscheck='MATCH'),
                        dict(seq=r2,q=q,crosscheck='MATCH'),self.args(max_mismatches=0))
        self.assertEqual(result['status'],'REVIEW')

if __name__ == '__main__':
    unittest.main(verbosity=2)
