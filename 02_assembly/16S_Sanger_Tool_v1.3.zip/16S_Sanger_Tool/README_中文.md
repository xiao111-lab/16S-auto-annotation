# Sanger 16S 批量双端拼接工具 v1.3

本工具读取每株细菌 27F 和 1492R 方向的 `.ab1` 原始峰图，利用 Phred 值剪切测序末端、反向互补 1492R、进行局部序列比对、构建 27F 方向的 Consensus，并生成 CSV 质控报告和可上传 EzBioCloud 的合并 FASTA。`.seq` 是交叉核对文件，不代替 AB1 质量值。原始文件均不修改。

**v1.3 重点：针对部分单碱基 indel 生成自动修正候选，并把它们与真正 PASS 的样品严格区分。**

## 1. Mac 安装/更新

从 ChatGPT 下载 `16S_Sanger_Tool_v1.3.zip` 到 Mac 的 Downloads 文件夹，然后执行：

```bash
unzip -oq ~/Downloads/16S_Sanger_Tool_v1.3.zip -d ~/Downloads
bash ~/Downloads/16S_Sanger_Tool/run_16s.sh "/Users/xiaoyutongxue/Downloads/16S"
```

若已使用 v1.2，覆盖的仅是工具脚本，不删除旧的 `.venv`，不删除任何测序文件，不覆盖旧的 `16S_results_v1.2`。默认结果放在 `16S/16S_results_v1.3/`。首次安装需 Python 3.10–3.13；启动脚本会在工具专属 `.venv` 中安装 Biopython 1.85 预编译包，首次安装需联网。

打开结果目录：

```bash
open "/Users/xiaoyutongxue/Downloads/16S/16S_results_v1.3"
```

## 2. v1.3 中四种质控状态

- `PASS`：未出现 indel，且重叠长度、一致性、碱基质量冲突、尾段修剪等检查均通过。仅这些样品**默认**进入 EzBioCloud 上传 FASTA。
- `AUTO_CORRECTED`：只有一个 indel，满足下述严格条件，程序**暂时移除了一个可能多读的低质量碱基**。此为**待确认的候选序列**，不是与 PASS 等价的已验证序列。默认**不上传** EzBioCloud。
- `REVIEW`：有多个 indel、关键位置质量不够、错配无法确定、双端对齐冲突等，需要人工查峰图。
- `FAIL`：数据缺失、AB1 无质量信息、无法可靠比对等硬性错误。

## 3. 单碱基 indel 候选修正规则

仅同时满足以下条件，输出 `AUTO_CORRECTED`：

1. 整个双端重叠区只有 **1 个 gap 列**，并且**没有普通碱基错配**。
2. 多出来的碱基处在**连续相同碱基**区段（homopolymer）；鉴于 gap 在这个区段内可能滑动，检查整个同碱基区段的质量，最低 Phred **≤Q10**。
3. 另一方向在 gap 附近的四个比对位点均达到 **Q35**。
4. gap 两侧各至少有 **20 bp 连续完全匹配**。
5. 其他原有 QC 条件也通过，最后 Consensus 无 `N`。

这些是为了降低误判而设计的**经验规则**，不是经实验验证的 indel 真值鉴别模型。即使满足条件，Phred 也不能直接评价“缺失碱基”的置信度；程序目前**没有自动定量判读原始四通道峰形**。建议打开 27F/1492R AB1，重点复核这种候选修正，尤其是实际数据库鉴定或发表之前。所有冲突/证据都写入 `01_QC/<ID>_conflicts.json`。

如果没有充分证据，序列保留为 REVIEW；不会强行自动通过，也不会用参考数据库填补缺失。

### 修改阈值（只有明确需要时才改）

```bash
bash ~/Downloads/16S_Sanger_Tool/run_16s.sh "/Users/xiaoyutongxue/Downloads/16S" \
  --auto-indel-max-q 10 --auto-indel-support-q 35 --auto-indel-anchor 20
```

- `--auto-indel-max-q`：额外碱基所在等价重复区中允许的最高最低质量值（默认 10）。
- `--auto-indel-support-q`：无额外碱基方向四个临近位点的最低质量要求（默认 35）。
- `--auto-indel-anchor`：gap 两侧各需要的连续完全匹配长度（默认 20 bp）。
- `--disable-auto-indel`：关闭这项候选修正，所有 indel 保持 REVIEW。
- `--max-draft-indels 10`：允许生成 REVIEW 候选的最多 gap 列数（默认 10）。
- `--max-mismatches 3`、`--min-identity 99.0`：控制普通碱基错配和原始双端一致性，与 v1.2 一致。
- `--output <绝对目录>`：保存另一套不同参数的输出，避免混淆。

## 4. 文件输出

```text
16S_results_v1.3/
├── 01_QC/
│   ├── <ID>_alignment.txt
│   ├── <ID>_conflicts.json
│   ├── <ID>_quality.svg
│   ├── <ID>_27F_trimmed.fasta
│   └── <ID>_1492R_revcomp_trimmed.fasta
├── 02_Consensus/
│   ├── <ID>_consensus.fasta
│   ├── all_PASS_consensus.fasta
│   ├── all_AUTO_CORRECTED_provisional_NOT_VALIDATED.fasta
│   └── all_REVIEW_provisional_NOT_FOR_EZ.fasta
├── 03_EzBioCloud/
│   ├── all_PASS_for_EzBioCloud.fasta
│   ├── EzBioCloud_results_template.csv
│   └── HOW_TO_UPLOAD.txt
└── 04_Reports/
    ├── 16S_QC_summary.csv
    ├── Auto_Corrected_Review_List.csv
    ├── Need_Review_or_Fail.csv
    └── run_summary.json
```

`04_Reports/16S_QC_summary.csv` 在 Excel 中打开即可。新增 `auto_corrected_indels` 列；并保留每株菌 `overlap_indels`、 `overlap_mismatches`、Consensus 序列长度、N 个数、质量值等。

`01_QC/<ID>_conflicts.json` 对自动候选还会显示 `repeat_run_lowest_Q`、`repeat_run_qualities`、`anchor_left`、`anchor_right`、`other_read_flank_Q` 和 `correction` 等字段。

## 5. EzBioCloud 批量鉴定

默认的 `03_EzBioCloud/all_PASS_for_EzBioCloud.fasta` **只包含 PASS**。

你在看过峰图、确认 `AUTO_CORRECTED` 候选可靠后，如果明确希望同时把这些候选序列上传以供初筛，可以**主动选择**：

```bash
bash ~/Downloads/16S_Sanger_Tool/run_16s.sh "/Users/xiaoyutongxue/Downloads/16S" \
  --include-auto-corrected-ez
```

这样重新生成的 `all_PASS_for_EzBioCloud.fasta` 会包含 `PASS + AUTO_CORRECTED`；必须记住后者依然是**未经正式验证的候选修正**。脚本不会联网登录 EzBioCloud，上传及下载平台报告仍需人工完成。

EzBioCloud 官方网站：https://www.ezbiocloud.net/

若已填写 `EzBioCloud_results_template.csv`，想合并鉴定结果与质控表：

```bash
bash ~/Downloads/16S_Sanger_Tool/run_16s.sh "/Users/xiaoyutongxue/Downloads/16S" \
  --merge-ez "/Users/xiaoyutongxue/Downloads/16S/16S_results_v1.3/03_EzBioCloud/EzBioCloud_results_template.csv"
```

## 6. 真实样本验证与风险

在 104 号菌的原始 AB1 上，v1.2 检出 1 个 gap，额外碱基所在重复区存在 Q6；v1.3 输出 1,331 bp 的 `AUTO_CORRECTED` 候选，与此前人工检查生成的候选 FASTA 一致。**这只验证算法可重现候选，不保证所有真实单碱基 indel 都是测序错误**。以完整 83 株重跑后的状态统计为准。

程序对 indel 的评价是一种保守的筛查方法；对高质量但不一致的区域必须人工审查。样品鉴定结果与“可以在 SCI 论文中发表的高可信序列”也应区别对待。全部原始 AB1/SEQ 不会修改。

## 7. 开发测试

在工具目录执行：

```bash
./.venv/bin/python tests.py
```

包括干净读序、普通错配、低 Q 单 indel、高 Q 单 indel、可禁用自动修正、另一方向支持质量不足、重复运行目录排除等测试。
