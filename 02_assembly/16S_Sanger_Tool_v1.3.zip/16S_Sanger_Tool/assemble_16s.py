#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Batch 27F/1492R Sanger 16S assembler. Keeps original AB1/SEQ unchanged.

Requires Biopython; everything else is standard Python.
"""
import argparse
import csv
import json
import re
import sys
import traceback
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from statistics import mean, median

from Bio import SeqIO
from Bio.Align import PairwiseAligner
from Bio.Seq import Seq

VERSION = "1.3.0"
READ_DIRECTIONS = re.compile(r"(?<![A-Za-z0-9])(1492R|27F)(?![A-Za-z0-9])", re.I)
ALPHABET = set("ACGTRYSWKMBDHVN")
QC_COLUMNS = [
    "strain_id", "sample_key", "status", "reason", "27F_AB1", "1492R_AB1",
    "27F_raw_bp", "1492R_raw_bp", "27F_trim_bp", "1492R_trim_bp",
    "27F_trim_start_0based", "27F_trim_stop_0based", "1492R_trim_start_0based",
    "1492R_trim_stop_0based", "overlap_bp", "overlap_identity_pct",
    "overlap_mismatches", "overlap_indels", "auto_corrected_indels", "resolved_mismatches", "unresolved_mismatches", "27F_discarded_3prime_bp",
    "1492R_discarded_3prime_bp", "consensus_bp", "consensus_N",
    "consensus_Qlt20", "consensus_meanQ", "SEQ_cross_check", "consensus_path",
]
EZ_FIELDS = ["strain_id", "closest_species", "type_strain", "similarity_pct", "coverage_pct", "accession", "notes"]


def norm_id(s):
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", s).strip("._-") or "sample"


def split_name(p):
    m = READ_DIRECTIONS.search(p.stem)
    if m is None:
        return None
    direction = m.group(1).upper()
    if direction not in ("27F", "1492R"):
        return None
    # Replacing only the primer label pairs the user's real N6 files reliably.
    sample_key = (p.stem[:m.start()] + "_DIRECTION_" + p.stem[m.end():]).strip("_- .")
    sample_key = re.sub(r"[_ .-]+", "_", sample_key)
    head = p.stem[:m.start()].strip("_- .")
    sample_id = head.split("_")[0].strip("_- .") if head else ""
    # Fallback for filenames such as 27F_N6 (sample follows direction).
    if not sample_id:
        rest = p.stem[m.end():].strip("_- .")
        sample_id = rest.split("_")[0] if rest else sample_key.replace("_DIRECTION_", "")
    return (sample_key, norm_id(sample_id), direction)


def scan_files(input_dir, output_dir):
    groups = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
    for path in sorted(input_dir.rglob("*")):
        if not path.is_file():
            continue
        if output_dir == path or output_dir in path.parents:
            continue
        # An earlier version stores 27F/1492R FASTAs inside 16S_results.
        # Those are outputs, not new samples; exclude all historical results.
        if any(part.lower().startswith('16s_results') for part in path.relative_to(input_dir).parts[:-1]):
            continue
        if path.suffix.lower() not in (".ab1", ".abi", ".seq", ".fasta", ".fa", ".fna"):
            continue
        parsed = split_name(path)
        if not parsed:
            continue
        key, sample_id, direction = parsed
        # Parent directory in grouping avoids silently pairing unrelated runs.
        rel = str(path.parent.relative_to(input_dir))
        groups[(rel, key, sample_id)][direction][path.suffix.lower()].append(path)
    return groups


def read_seq_sidecar(path):
    content = path.read_text(encoding="utf-8-sig", errors="replace")
    lines = [s.strip() for s in content.splitlines() if s.strip()]
    if lines and lines[0].startswith(">"):
        lines = [s for s in lines if not s.startswith(">")]
    s = "".join(lines).replace(" ", "").replace("\t", "").upper()
    return s


def abi_file(files):
    paths = files.get(".ab1", []) + files.get(".abi", [])
    if len(paths) != 1:
        raise ValueError("需要恰好一个AB1文件；当前数量: " + str(len(paths)))
    return paths[0]


def load_read(files):
    path = abi_file(files)
    record = SeqIO.read(str(path), "abi")
    seq = str(record.seq).upper()
    qs = list(record.letter_annotations.get("phred_quality", []))
    if not qs or len(qs) != len(seq):
        raise ValueError("AB1未包含完整Phred碱基质量信息")
    if any(b not in ALPHABET for b in seq):
        raise ValueError("AB1序列包含无法处理的碱基符号")
    seq_files = sum((files.get(ext, []) for ext in (".seq", ".fasta", ".fa", ".fna")), [])
    crosscheck = "NO_SEQ_FILE"
    if len(seq_files) == 1:
        side_seq = read_seq_sidecar(seq_files[0])
        crosscheck = "MATCH" if side_seq == seq else "MISMATCH"
    elif len(seq_files) > 1:
        crosscheck = "MULTIPLE_SEQ_FILES"
    return dict(path=path, seq=seq, q=qs, crosscheck=crosscheck)


def trim_quality(seq, q, window=40, q_threshold=25.0, min_length=150):
    """Find the longest contiguous interval whose centered moving-window QC passes.
    This deliberately errs towards high-quality core sequence; second-stage assembly
    additionally drops unsupported read tips (never fills gaps by reference).
    """
    n = len(seq)
    if n < min_length:
        raise ValueError(f"原始序列不足 {min_length} bp")
    half = window // 2
    prefix = [0]
    prefix20 = [0]
    for v in q:
        prefix.append(prefix[-1] + v)
        prefix20.append(prefix20[-1] + (v >= 20))
    passing = []
    for i in range(n):
        l = max(0, i - half)
        r = min(n, i + half)
        width = r - l
        avg = (prefix[r] - prefix[l]) / width
        good_frac = (prefix20[r] - prefix20[l]) / width
        passing.append(avg >= q_threshold and good_frac >= 0.60)
    runs = []
    start = None
    for i, yes in enumerate(passing + [False]):
        if yes and start is None:
            start = i
        elif not yes and start is not None:
            runs.append((start, i))
            start = None
    if not runs:
        raise ValueError("没有找到符合质量条件的连续测序区间")
    start, stop = max(runs, key=lambda pair: pair[1] - pair[0])
    if stop - start < min_length:
        raise ValueError("质量修剪后序列过短")
    return (start, stop, seq[start:stop], q[start:stop])


def assess_single_indel(columns, gap_index, F, Fq, R, Rq, args):
    """Suggest omission of a single low-Q extra base; does NOT prove the true allele.

    Gaps in short repeats may slide between equally scoring alignment columns.
    The original position and diagnostic evidence are retained for manual review.
    This routine uses PHRED and local paired agreement, not raw peak morphology.
    """
    fi, ri = columns[gap_index]
    source = "27F" if fi >= 0 else "1492R"
    source_seq, source_q = (F, Fq) if fi >= 0 else (R, Rq)
    idx = fi if fi >= 0 else ri
    base, q = source_seq[idx], source_q[idx]
    # In a homopolymer the aligner's one-gap placement is arbitrary.
    # Any identical base in the run can be the extra observation. Look at
    # all qualities across the equivalent deletion positions, report them.
    run_start,run_end=idx,idx+1
    while run_start>0 and source_seq[run_start-1]==base: run_start-=1
    while run_end<len(source_seq) and source_seq[run_end]==base: run_end+=1
    run_q=source_q[run_start:run_end]
    evidence = dict(source=source, base=base, extra_base_Q=q,
                    repeat_run_lowest_Q=min(run_q), repeat_run_qualities=run_q,
                    repeat_run_coordinates_0based=[run_start,run_end],
                    anchor_left=0, anchor_right=0,
                    other_read_flank_Q=[], repeat_base=False,
                    decision="REVIEW", reason="")
    if args.disable_auto_indel:
        evidence['reason'] = "已禁用自动indel候选修正"
        return evidence
    if base not in "ACGT":
        evidence['reason'] = "额外碱基为模糊碱基"
        return evidence
    in_repeat = run_end-run_start>=2
    evidence['repeat_base'] = in_repeat
    if not in_repeat:
        evidence['reason'] = "缺少相邻相同碱基，不能假定为重复区读序误差"
        return evidence
    if min(run_q) > args.auto_indel_max_q:
        evidence['reason'] = f"整个等价重复区的最低Q{min(run_q)}高于阈值Q{args.auto_indel_max_q}"
        return evidence
    a = gap_index - 1
    while a >= 0:
        x,y=columns[a]
        if x<0 or y<0 or F[x]!=R[y]: break
        evidence['anchor_left'] += 1
        a -= 1
    b = gap_index + 1
    while b < len(columns):
        x,y=columns[b]
        if x<0 or y<0 or F[x]!=R[y]: break
        evidence['anchor_right'] += 1
        b += 1
    if min(evidence['anchor_left'], evidence['anchor_right']) < args.auto_indel_anchor:
        evidence['reason'] = f"indel两侧连续匹配分别只有{evidence['anchor_left']}/{evidence['anchor_right']}bp"
        return evidence
    # On the *other* read there is no extra base, so inspect the quality of
    # the immediate flanking observations (no fictitious deletion Phred).
    other_q = Fq if fi < 0 else Rq
    idxs = []
    for j in range(gap_index-2, gap_index+3):
        if j == gap_index or j < 0 or j >= len(columns): continue
        x,y=columns[j]
        oi = x if fi < 0 else y
        if oi >= 0: idxs.append(oi)
    qs = [other_q[i] for i in idxs]
    evidence['other_read_flank_Q'] = qs
    if len(qs) < 4 or min(qs) < args.auto_indel_support_q:
        evidence['reason'] = f"无插入方向的邻近峰质量不足（{qs}；需每个至少Q{args.auto_indel_support_q}）"
        return evidence
    evidence['decision'] = 'OMIT_EXTRA_BASE_PROVISIONAL'
    evidence['reason'] = '重复区存在低Q碱基、另一端高Q、两侧有足够连续匹配；自动生成候选修正（gap位置在重复区内非唯一）'
    return evidence


def assemble(f, r, args):
    """Quality-aware two-read consensus in 27F direction.

    Raw base discordances are kept in the QC report even when confidently
    resolved by Phred qualities. Internal indels produce REVIEW drafts only;
    they must NOT be silently approved or submitted as validated sequences.
    """
    fs, fe, F, Fq = trim_quality(f["seq"], f["q"], args.window, args.window_q, args.min_read)
    rs, re, Rraw, Rq_raw = trim_quality(r["seq"], r["q"], args.window, args.window_q, args.min_read)
    R = str(Seq(Rraw).reverse_complement())
    Rq = list(reversed(Rq_raw))

    aligner = PairwiseAligner(mode="local", match_score=2.0, mismatch_score=-5.0,
                              open_gap_score=-120.0, extend_gap_score=-10.0)
    alignments = aligner.align(F, R)
    if not alignments:
        raise ValueError("双端没有可用的局部比对")
    alignment = alignments[0]
    f_idx, r_idx = alignment.indices
    columns = [(int(fi), int(ri)) for fi, ri in zip(f_idx, r_idx)]
    paired = [(fi, ri) for fi, ri in columns if fi >= 0 and ri >= 0]
    if len(paired) < args.min_overlap:
        raise ValueError(f"双端重叠区域不足最小要求({len(paired)} < {args.min_overlap})")
    firstF, firstR = paired[0]
    lastF, lastR = paired[-1]
    if firstF > 0 and lastR < len(R) - 1:
        pass  # normal inward-facing read arrangement
    elif firstF < 0 or lastR < 0:
        raise ValueError("比对无法确定双端相对位置")
    f_tail = len(F) - (lastF + 1)
    r_head = firstR
    gaps = sum(fi < 0 or ri < 0 for fi, ri in columns)
    if gaps > args.max_draft_indels:
        raise ValueError(f"双端比对存在{gaps}个indel列，超过候选组装上限{args.max_draft_indels}；请人工核查")
    gap_positions = [i for i, (fi, ri) in enumerate(columns) if fi < 0 or ri < 0]
    mismatch_positions = [i for i, (fi, ri) in enumerate(columns)
                          if fi >= 0 and ri >= 0 and F[fi] != R[ri]]
    indel_evidence = None
    # Only one gap AND zero substituted bases permits an automatic *candidate*.
    if len(gap_positions) == 1 and not mismatch_positions:
        indel_evidence = assess_single_indel(columns, gap_positions[0], F, Fq, R, Rq, args)
    differences, indels = [], []
    cons_overlap, qual_overlap = [], []
    seen, match_count = 0, 0
    resolved, unresolved, auto_corrected_indels = 0, 0, 0
    for column_index, (fi, ri) in enumerate(columns):
        if fi >= 0 and ri >= 0:
            a, b = F[fi], R[ri]
            qa, qb = Fq[fi], Rq[ri]
            seen += 1
            if a == b:
                match_count += 1
                cons_overlap.append(a)
                qual_overlap.append(max(qa, qb))
                continue
            confidence = (a in "ACGT" and b in "ACGT" and
                          max(qa, qb) >= args.confident_q and
                          abs(qa-qb) >= args.min_q_diff)
            if confidence:
                base = a if qa > qb else b
                resolved += 1
            elif a in "ACGT" and b == "N" and qa >= args.confident_q:
                base = a
                resolved += 1
            elif b in "ACGT" and a == "N" and qb >= args.confident_q:
                base = b
                resolved += 1
            else:
                # Do not turn a one-point Q advantage into an unjustified call.
                base = "N"
                unresolved += 1
            cons_overlap.append(base)
            qual_overlap.append(max(qa, qb) if base != "N" else min(qa, qb))
            differences.append(dict(event="mismatch", consensus_position=firstF+len(cons_overlap),
                                    forward_pos=fs+fi+1, reverse_raw_pos=re-ri,
                                    forward_base=a, reverse_base=b,
                                    forward_Q=qa, reverse_Q=qb, consensus_base=base,
                                    quality_resolved=bool(base!="N")))
        else:
            # There is no Phred value for a deletion. An indel cannot be
            # 'resolved by choosing the higher-Q read' like a mismatch.
            # Retain the base observed on one read as a *provisional* draft,
            # and require manual confirmation of the chromatograms.
            if fi >= 0:
                base, q = F[fi], Fq[fi]
                source, forward_pos, reverse_raw_pos = "27F", fs+fi+1, None
            else:
                base, q = R[ri], Rq[ri]
                source, forward_pos, reverse_raw_pos = "1492R", None, re-ri
            auto_omit = (indel_evidence is not None and
                         column_index == gap_positions[0] and
                         indel_evidence['decision'] == 'OMIT_EXTRA_BASE_PROVISIONAL')
            # Do not add the poorly-supported extra base to the consensus.
            # On a high-confidence paired read, the *absence* of this base
            # has no calibrated Phred score: the result is a candidate only.
            if auto_omit:
                auto_corrected_indels += 1
            else:
                cons_overlap.append(base if base in "ACGT" and q >= 20 else "N")
                qual_overlap.append(q)
            indels.append(dict(event="indel", consensus_position=firstF+len(cons_overlap),
                               source=source, base=base, Phred=q,
                               forward_pos=forward_pos, reverse_raw_pos=reverse_raw_pos,
                               correction="OMITTED_EXTRA_BASE_PROVISIONAL" if auto_omit else "UNRESOLVED",
                               evidence=indel_evidence if indel_evidence else
                               {"decision":"REVIEW","reason":"超过一个indel列或有其他碱基错配"}))

    consensus = F[:firstF] + "".join(cons_overlap) + R[lastR+1:]
    qualities = Fq[:firstF] + qual_overlap + Rq[lastR+1:]
    identity = 100.0 * match_count / seen
    status = "PASS"
    reasons = []
    if firstF < args.min_overlap // 2 or len(R) - 1 - lastR < args.min_overlap // 2:
        reasons.append("双端拼接后单端延伸较短，请核对覆盖范围")
    if f_tail > args.max_tail_discard or r_head > args.max_tail_discard:
        reasons.append(f"对齐前需额外舍弃测序尾段过长(F={f_tail},R={r_head})")
    if f_tail >= 10 and median(Fq[-f_tail:]) >= 35:
        reasons.append("27F舍弃的尾段质量仍偏高，检查可能的indel")
    if r_head >= 10 and median(Rq[:r_head]) >= 35:
        reasons.append("1492R舍弃的尾段质量仍偏高，检查可能的indel")
    if differences:
        reasons.append(f"双端错配{len(differences)}个：按Phred解决{resolved}个，仍不确定{unresolved}个")
    if len(differences) > args.max_mismatches:
        reasons.append(f"错配数{len(differences)}超过阈值{args.max_mismatches}，需复核")
    if unresolved:
        reasons.append("存在无法凭质量可靠决定的冲突碱基")
    if identity < args.min_identity:
        reasons.append(f"原始重叠区一致性 {identity:.3f}% 小于阈值 {args.min_identity}%")
    if gaps:
        if auto_corrected_indels:
            reasons.append("自动候选修正1个低Q indel：已省略一端多读碱基，仍建议人工复核AB1峰图")
        else:
            detail = (indel_evidence['reason'] if indel_evidence else "多个indel或同时存在其他错配")
            reasons.append(f"双端重叠区存在{gaps}个indel列：{detail}，保留REVIEW")
    if "N" in consensus:
        reasons.append("一致性序列含模糊碱基 N")
    if f["crosscheck"] in ("MISMATCH", "MULTIPLE_SEQ_FILES") or r["crosscheck"] in ("MISMATCH", "MULTIPLE_SEQ_FILES"):
        reasons.append("AB1与SEQ文件不匹配，或有多个SEQ文件")
    nonblocking_info = (f"双端错配{len(differences)}个：按Phred解决{resolved}个，仍不确定{unresolved}个"
                        if differences else None)
    auto_annotation = ("自动候选修正1个低Q indel：已省略一端多读碱基，仍建议人工复核AB1峰图"
                       if auto_corrected_indels else None)
    blocking = [reason for reason in reasons if reason not in (nonblocking_info, auto_annotation)]
    if blocking:
        status = "REVIEW"
    elif auto_corrected_indels:
        status = "AUTO_CORRECTED"  # Deliberately NOT an unqualified PASS.
    else:
        status = "PASS"
    return dict(fs=fs, fe=fe, rs=rs, re=re, F=F, R=R, Fq=Fq, Rq=Rq,
                f_start=firstF, f_end=lastF, r_start=firstR, r_end=lastR,
                f_tail=f_tail, r_head=r_head, overlap=seen, overlap_columns=len(columns),
                alignment_columns=columns, identity=identity,
                mismatches=len(differences), gaps=gaps, auto_corrected_indels=auto_corrected_indels, differences=differences,
                indels=indels, resolved_mismatches=resolved,
                unresolved_mismatches=unresolved,
                consensus=consensus, qualities=qualities, status=status,
                reason="；".join(reasons) if reasons else "双端拼接通过质量检查")


def fasta_write(path, name, seq):
    with path.open("w", encoding="utf-8") as fh:
        fh.write(f">{name}\n")
        for off in range(0, len(seq), 80):
            fh.write(seq[off:off+80] + "\n")


def csv_write(path, rows, fields):
    with path.open("w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def svg_quality(path, f, r, result):
    # Dependency-free quality plot: 10-bp bin mean. Openable in any browser.
    width, height = 1180, 420
    lines = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
             '<rect width="100%" height="100%" fill="white"/>',
             '<text x="55" y="32" fill="#102a43" font-family="Arial" font-size="20" font-weight="bold">Sanger Phred quality (raw AB1, 10-bp windows)</text>']
    colors = [("27F",f["q"],result["fs"],result["fe"],"#008577",65),
              ("1492R",r["q"],result["rs"],result["re"],"#315dba",240)]
    for name, qs, start, stop, color, y0 in colors:
        x0, plot_w, plot_h = 75, 1010, 120
        bins = [(i,mean(qs[i:i+10])) for i in range(0,len(qs),10)]
        xmax = len(qs)
        y_coord = lambda v:y0+plot_h - min(v,70)/70*plot_h
        x_coord = lambda i:x0+i/xmax*plot_w
        lines += [f'<text x="75" y="{y0-7}" fill="{color}" font-family="Arial" font-size="15">{name}: raw {len(qs)} bp; retained {start}:{stop}</text>',
                  f'<rect x="{x_coord(start):.1f}" y="{y0}" width="{x_coord(stop)-x_coord(start):.1f}" height="{plot_h}" fill="#cbf3db" opacity="0.8"/>',
                  f'<line x1="{x0}" x2="{x0+plot_w}" y1="{y_coord(20):.1f}" y2="{y_coord(20):.1f}" stroke="#a45a26" stroke-dasharray="5,5"/>',
                  f'<text x="1100" y="{y_coord(20)+4:.1f}" font-family="Arial" font-size="11" fill="#a45a26">Q20</text>',
                  f'<line x1="{x0}" x2="{x0+plot_w}" y1="{y0+plot_h}" y2="{y0+plot_h}" stroke="#777"/>']
        pts=" ".join(f'{x_coord(i+5):.1f},{y_coord(v):.1f}' for i,v in bins)
        lines.append(f'<polyline points="{pts}" fill="none" stroke="{color}" stroke-width="2" stroke-linejoin="round"/>')
    lines.append('</svg>')
    path.write_text("\n".join(lines),encoding="utf-8")


def save_alignment(path, row, result):
    F, R = result["F"], result["R"]
    f0, r0 = result["f_start"], result["r_start"]
    columns = result["alignment_columns"]
    overlap_f = "".join(F[fi] if fi >= 0 else "-" for fi, ri in columns)
    overlap_r = "".join(R[ri] if ri >= 0 else "-" for fi, ri in columns)
    with path.open("w", encoding="utf-8") as o:
        o.write(f"Sample: {row['strain_id']}\nBoth sequences oriented as 27F (5' -> 3').\n")
        o.write(f"27F raw trim (0-based): {result['fs']}:{result['fe']}\n")
        o.write(f"1492R raw trim (0-based): {result['rs']}:{result['re']}\n")
        o.write(f"Post-trim overlap (27F coordinate): {f0+1}..{result['f_end']+1}\n")
        o.write(f"Post-trim overlap (1492R reverse-complement coordinate): {r0+1}..{result['r_end']+1}\n")
        o.write(f"Overlap={result['overlap']} paired bp, identity={result['identity']:.3f}%, "
                f"mismatches={result['mismatches']}, indel columns={result['gaps']}\n")
        o.write(f"Auto-corrected indels (provisional)={result['auto_corrected_indels']}\n")
        o.write(f"Resolved mismatches by Phred={result['resolved_mismatches']}; "
                f"unresolved={result['unresolved_mismatches']}\n")
        o.write(f"Discarded after trim: 27F 3' tail={result['f_tail']} bp; "
                f"1492R raw 3' tail={result['r_head']} bp\n")
        o.write(f"Status={row['status']}; note={row['reason']}\n\n")
        for off in range(0, len(columns), 80):
            a, b = overlap_f[off:off+80], overlap_r[off:off+80]
            marks = "".join("|" if x == y else ("^" if "-" in (x, y) else "*")
                            for x, y in zip(a, b))
            o.write(f"27F    {off+1:>5} {a}\n             {marks}\n1492R {off+1:>5} {b}\n\n")
        if result["differences"] or result["indels"]:
            o.write("\nDifferences / indels (1-based):\n")
            o.write(json.dumps(result["differences"]+result["indels"], ensure_ascii=False, indent=2)+"\n")


def process(args):
    input_dir = Path(args.input).expanduser().resolve()
    if not input_dir.is_dir():
        sys.exit("错误：输入文件夹不存在：" + str(input_dir))
    output_dir = (Path(args.output).expanduser().resolve() if args.output else input_dir / "16S_results_v1.3")
    if input_dir == output_dir:
        sys.exit("错误：输出目录不能与输入目录相同")
    qc_dir = output_dir / "01_QC"
    seq_dir = output_dir / "02_Consensus"
    ez_dir = output_dir / "03_EzBioCloud"
    report_dir = output_dir / "04_Reports"
    for p in [qc_dir,seq_dir,ez_dir,report_dir]:p.mkdir(parents=True,exist_ok=True)
    groups = scan_files(input_dir, output_dir)
    id_counts = Counter(sample_id for (_,_,sample_id) in groups)
    rows=[]
    assembled=[]
    review_drafts=[]
    auto_corrected=[]
    states=Counter()
    for (rel, key, sample_id), orientations in sorted(groups.items(), key=lambda x:(x[0][2],x[0][0])):
        print("处理",sample_id, "[",rel,"]", flush=True)
        row={k:"" for k in QC_COLUMNS}
        row.update(strain_id=sample_id, sample_key=f"{rel}/{key}", status="FAIL")
        try:
            if id_counts[sample_id] != 1:
                raise ValueError("菌株编号冲突：在输入目录中发现多个同名样品组，禁止覆盖。请修改文件名")
            f=load_read(orientations.get("27F",{}))
            r=load_read(orientations.get("1492R",{}))
            row.update({"27F_AB1":str(f["path"]),"1492R_AB1":str(r["path"]),
                        "27F_raw_bp":len(f["seq"]),"1492R_raw_bp":len(r["seq"]),
                        "SEQ_cross_check":f"27F:{f['crosscheck']};1492R:{r['crosscheck']}"})
            # Even when assembly fails, preserve both quality-trimmed reads for inspection.
            _fs,_fe,_F,_Fq = trim_quality(f["seq"],f["q"],args.window,args.window_q,args.min_read)
            _rs,_re,_R,_Rq = trim_quality(r["seq"],r["q"],args.window,args.window_q,args.min_read)
            fasta_write(qc_dir/(sample_id+"_27F_trimmed.fasta"),sample_id+"_27F",_F)
            fasta_write(qc_dir/(sample_id+"_1492R_revcomp_trimmed.fasta"),
                        sample_id+"_1492R_RC",str(Seq(_R).reverse_complement()))
            result=assemble(f,r,args)
            row.update(status=result["status"], reason=result["reason"],
                **{"27F_trim_bp":len(result["F"]),"1492R_trim_bp":len(result["R"]),
                   "27F_trim_start_0based":result["fs"],"27F_trim_stop_0based":result["fe"],
                   "1492R_trim_start_0based":result["rs"],"1492R_trim_stop_0based":result["re"],
                   "overlap_bp":result["overlap"],"overlap_identity_pct":round(result["identity"],3),
                   "overlap_mismatches":result["mismatches"],"overlap_indels":result["gaps"],
                   "auto_corrected_indels":result["auto_corrected_indels"],
                   "resolved_mismatches":result["resolved_mismatches"],
                   "unresolved_mismatches":result["unresolved_mismatches"],
                   "27F_discarded_3prime_bp":result["f_tail"],
                   "1492R_discarded_3prime_bp":result["r_head"],
                   "consensus_bp":len(result["consensus"]),
                   "consensus_N":result["consensus"].count('N'),
                   "consensus_Qlt20":sum(x<20 for x in result["qualities"]),
                   "consensus_meanQ":round(mean(result["qualities"]),2)})
            # Per-sample FASTA always available, but only PASS enters EZ upload FASTA.
            file_path=seq_dir/(sample_id+"_consensus.fasta")
            fasta_write(file_path,sample_id,result["consensus"])
            row["consensus_path"]=str(file_path)
            save_alignment(qc_dir/(sample_id+"_alignment.txt"),row,result)
            svg_quality(qc_dir/(sample_id+"_quality.svg"),f,r,result)
            (qc_dir/(sample_id+"_conflicts.json")).write_text(
                json.dumps(result["differences"]+result["indels"],indent=2,ensure_ascii=False),encoding="utf-8")
            if result["status"] == "PASS":
                assembled.append((sample_id,result["consensus"]))
            elif result["status"] == "AUTO_CORRECTED":
                auto_corrected.append((sample_id,result["consensus"]))
            elif result["status"] == "REVIEW":
                review_drafts.append((sample_id,result["consensus"]))
        except Exception as err:
            row['reason'] = str(err)
            if 'indel' in str(err).lower():
                row['status']='REVIEW'
        states[row["status"]]+=1
        rows.append(row)
        print(f"  -> {row['status']}: {row['reason']} ; {row.get('consensus_bp','')} bp",flush=True)
    csv_write(report_dir/"16S_QC_summary.csv",rows,QC_COLUMNS)
    csv_write(report_dir/"Need_Review_or_Fail.csv",[r for r in rows if r['status'] not in ('PASS','AUTO_CORRECTED')],QC_COLUMNS)
    csv_write(report_dir/"Auto_Corrected_Review_List.csv",[r for r in rows if r['status']=='AUTO_CORRECTED'],QC_COLUMNS)
    fasta_path=ez_dir/"all_PASS_for_EzBioCloud.fasta"
    with fasta_path.open('w',encoding='utf-8') as fh:
        for sid,s in assembled + (auto_corrected if args.include_auto_corrected_ez else []):
            fh.write(">"+sid+"\n")
            for off in range(0,len(s),80):fh.write(s[off:off+80]+"\n")
    with (seq_dir/"all_REVIEW_provisional_NOT_FOR_EZ.fasta").open('w',encoding='utf-8') as fh:
        for sid,seq in review_drafts:
            fh.write(f">{sid} REVIEW_PROVISIONAL_NOT_VALIDATED\n")
            for off in range(0,len(seq),80):fh.write(seq[off:off+80]+"\n")
    with (seq_dir/"all_AUTO_CORRECTED_provisional_NOT_VALIDATED.fasta").open('w',encoding='utf-8') as fh:
        for sid,seq in auto_corrected:
            fh.write(f">{sid} AUTO_CORRECTED_PROVISIONAL_CHECK_AB1\n")
            for off in range(0,len(seq),80):fh.write(seq[off:off+80]+"\n")
    with (seq_dir/"all_PASS_consensus.fasta").open('w',encoding='utf-8') as fh:
        for sid,seq in assembled:
            fh.write(f">{sid}\n")
            for off in range(0,len(seq),80):fh.write(seq[off:off+80]+"\n")
    ez_template=ez_dir/"EzBioCloud_results_template.csv"
    current_ids=[sid for sid,_ in (assembled + (auto_corrected if args.include_auto_corrected_ez else []))]
    # Preserve user-filled identification columns when re-running; never overwrite.
    if ez_template.exists():
        try:
            with ez_template.open('r',encoding='utf-8-sig',newline='') as stream:
                previous={row['strain_id']:row for row in csv.DictReader(stream) if row.get('strain_id')}
            if set(current_ids)-set(previous):
                csv_write(ez_template,[previous.get(sid,{'strain_id':sid}) for sid in current_ids],EZ_FIELDS)
        except (KeyError,UnicodeError,csv.Error):
            print('警告：EzBioCloud已有模板格式无法识别，原文件保持不变',file=sys.stderr)
    else:
        csv_write(ez_template,[dict(strain_id=sid) for sid in current_ids],EZ_FIELDS)
    info={"pipeline_version":VERSION,"created_at":datetime.now().isoformat(timespec="seconds"),
          "input_directory":str(input_dir),"output_directory":str(output_dir),
          "counts":dict(states),"sample_groups":len(groups),
          "parameters":{"window":args.window,"window_q":args.window_q,
                        "min_read":args.min_read,"min_overlap":args.min_overlap,
                        "min_identity":args.min_identity,"max_tail_discard":args.max_tail_discard,
                        "max_mismatches":args.max_mismatches,"min_q_diff":args.min_q_diff,
                        "confident_q":args.confident_q,"max_draft_indels":args.max_draft_indels,
                        "auto_indel_max_q":args.auto_indel_max_q,"auto_indel_support_q":args.auto_indel_support_q,
                        "auto_indel_anchor":args.auto_indel_anchor,"disable_auto_indel":args.disable_auto_indel,
                        "include_auto_corrected_ez":args.include_auto_corrected_ez},
          "ezbiocloud_status":"NOT_SUBMITTED; upload PASS FASTA manually. AUTO_CORRECTED excluded unless explicitly opted in. REVIEW excluded."}
    (report_dir/"run_summary.json").write_text(json.dumps(info,ensure_ascii=False,indent=2),encoding="utf-8")
    (ez_dir/"HOW_TO_UPLOAD.txt").write_text(
        "EzBioCloud 16S Identification:\n"
        "1. 登录 https://www.ezbiocloud.net/ ，打开16S Identification。\n"
        "2. Batch Upload 上传 all_PASS_for_EzBioCloud.fasta（可能使用credits）。\n"
        "3. 下载鉴定报告（网站帮助中为PDF）。保留报告，不要把未识别的PDF当成CSV。\n"
        "4. 若要与QC汇总自动合并，在EzBioCloud_results_template.csv中输入相应菌株的鉴定结果，\n"
        "   再运行 bash run_16s.sh <数据目录> --merge-ez <填写好的CSV路径>。\n"
        "说明：这套工具不登录网站、不调用未知接口、不伪造物种鉴定结果。\n"
        "AUTO_CORRECTED是根据质量和比对证据生成的候选修正，默认不自动提交；\n"
        "建议复核峰图后再考虑使用 --include-auto-corrected-ez 将候选并入上传文件。\n",
        encoding="utf-8")
    print("\n============== 批量组装完成 ==============")
    print(f"样品组数: {len(groups)}; PASS: {states['PASS']}; AUTO_CORRECTED: {states['AUTO_CORRECTED']}; REVIEW: {states['REVIEW']}; FAIL: {states['FAIL']}")
    print("结果文件夹:",output_dir)
    print("QC表:",report_dir/"16S_QC_summary.csv")
    print("EzBioCloud批量上传 (默认仅PASS):",fasta_path)
    if auto_corrected:
        print("待确认的自动indel修正候选:",seq_dir/"all_AUTO_CORRECTED_provisional_NOT_VALIDATED.fasta")
    if len(groups) == 0:
        print("警告：未扫描到含有[27F]或[1492R]名称的输入文件。",file=sys.stderr)
    return 0 if len(groups)>0 else 2


def merge_ez(args):
    input_dir=Path(args.input).expanduser().resolve()
    output_dir=(Path(args.output).expanduser().resolve() if args.output else input_dir/"16S_results_v1.3")
    qc_file=output_dir/"04_Reports"/"16S_QC_summary.csv"
    if not qc_file.exists():
        sys.exit("请先运行拼接流程，缺少QC报告："+str(qc_file))
    ez_file=Path(args.merge_ez).expanduser().resolve()
    if not ez_file.is_file():sys.exit("鉴定结果CSV不存在："+str(ez_file))
    def read_csv(path):
        with path.open('r',encoding='utf-8-sig',newline='') as fh:
            return list(csv.DictReader(fh))
    qc=read_csv(qc_file)
    ez=read_csv(ez_file)
    if not ez or not set(EZ_FIELDS).issubset(set(ez[0])):
        sys.exit("EzBioCloud CSV列名不符合模板格式；请使用生成的EzBioCloud_results_template.csv")
    by_id={}
    for hit in ez:
        sid=(hit.get('strain_id') or '').strip()
        if not sid:continue
        if sid in by_id:sys.exit("EzBioCloud报告菌株编号重复："+sid)
        by_id[sid]=hit
    final=[]
    for qrow in qc:
        hit=by_id.get(qrow['strain_id'],{})
        final.append(dict(qrow,**{c:hit.get(c,'') for c in EZ_FIELDS if c!='strain_id'}))
    unknown=set(by_id)-{r['strain_id'] for r in qc}
    if unknown:
        print("注意：以下EzBioCloud编号在原始QC中不存在：",', '.join(sorted(unknown)))
    output=output_dir/"04_Reports"/"16S_with_EzBioCloud.csv"
    csv_write(output,final,QC_COLUMNS+[s for s in EZ_FIELDS if s!='strain_id'])
    print("已生成合并结果：",output)
    print("匹配到鉴定信息的菌株：",sum(bool(by_id.get(row['strain_id'],{}).get('closest_species')) for row in qc))
    return 0


def main():
    p=argparse.ArgumentParser(description="Sanger 16S 27F/1492R automatic batch assembly + EzBioCloud batch FASTA")
    p.add_argument('--input',required=True,help='输入文件夹（含AB1与SEQ）')
    p.add_argument('--output',help='输出目录（默认：输入目录/16S_results_v1.3，不覆盖旧结果）')
    p.add_argument('--window',type=int,default=40,help='移动质控窗口bp，默认40')
    p.add_argument('--window-q',type=float,default=25,help='窗口平均Phred阈值，默认25')
    p.add_argument('--min-read',type=int,default=150,help='最短修剪序列，默认150bp')
    p.add_argument('--min-overlap',type=int,default=150,help='最短重叠区，默认150bp')
    p.add_argument('--min-identity',type=float,default=99.0,help='重叠区最低原始一致性(%%)，默认99.0')
    p.add_argument('--max-mismatches',type=int,default=3,help='最多允许多少个按质量可靠解决的双端错配，默认3')
    p.add_argument('--min-q-diff',type=int,default=10,help='双端有冲突时，质量优势至少多少个Phred分，默认10')
    p.add_argument('--confident-q',type=int,default=30,help='被选中的碱基至少多少Phred，默认30')
    p.add_argument('--max-draft-indels',type=int,default=10,help='允许生成待复核候选组装的最多indel列数，默认10；永不自动PASS')
    p.add_argument('--auto-indel-max-q',type=int,default=10,help='单indel额外碱基Q上限，默认10')
    p.add_argument('--auto-indel-support-q',type=int,default=35,help='无额外碱基方向，四个临近位点各自Q下限，默认35')
    p.add_argument('--auto-indel-anchor',type=int,default=20,help='indel两侧连续匹配的最小bp数，默认20')
    p.add_argument('--disable-auto-indel',action='store_true',help='禁用indel自动候选修正（保留v1.2行为）')
    p.add_argument('--include-auto-corrected-ez',action='store_true',help='明确选择将AUTO_CORRECTED候选纳入EzBioCloud上传FASTA（建议先复核峰图）')
    p.add_argument('--max-tail-discard',type=int,default=80,help='对齐后允许舍弃单端末端最多bp，默认80')
    p.add_argument('--merge-ez',help='不重复组装：合并手动填写的EzBioCloud结果模板CSV')
    args=p.parse_args()
    if (args.window<10 or args.min_overlap<40 or args.min_read<50 or
            args.max_mismatches<0 or args.max_draft_indels<0 or args.min_q_diff<0 or
            not 0 <= args.confident_q <= 93 or not 0 <= args.min_identity <= 100 or
            not 0 <= args.auto_indel_max_q <= 93 or not 0 <= args.auto_indel_support_q <= 93 or
            args.auto_indel_anchor < 5):
        p.error('无效参数：window≥10, min-overlap≥40, min-read≥50；其他阈值须在允许范围内')
    code = merge_ez(args) if args.merge_ez else process(args)
    sys.exit(code)


if __name__=='__main__':
    main()
